package objectdemo;

public class demo2 {

      private int emp_id;
      public void set EmpID(int emp_id1)
      {
    	  emp_id =emp_id1;
      }
      public int get EmpID{
    	  return emp_id;
      }
      
      
	public static void main(String[] args) 
	{

       System.out.println("Hello Java");
	}

}
