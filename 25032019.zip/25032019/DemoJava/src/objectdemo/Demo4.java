package objectdemo;

public class Demo4 {

	public static void main(String[] args)
	{
		String fname="dsssdhhhhh ";
		int lengthString =fname.length();
		String newFname =fname.replace("d", "");
		int lengthString1 =newFname.length();

		{
		
            
			System.out.println(lengthString -lengthString1);
            
	}

}
}