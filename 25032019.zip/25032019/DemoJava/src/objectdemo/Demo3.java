package objectdemo;

public class Demo3 {

	public static void main(String[] args) 
	{
	 String a=	"hello \t hello";
	 
     System.out.println(a.length());
     System.out.println(a);
     
	}			

}
