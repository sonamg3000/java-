package objectdemo;

public class Student {       //object by reffernce 
	 int id;
	 String name;
}
	 class testStudent2
	 {
		 public static void main(String[] args) 
		 {
		Student s1=new Student();
		s1.id=122;
		s1.name="sonam";
		System.out.println(s1.id+" "+s1.name);
		 }

	}
	 

