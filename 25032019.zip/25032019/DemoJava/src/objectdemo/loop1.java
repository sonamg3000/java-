package objectdemo;

public class loop1 {

	public static void main(String[] args) 
	{
		char C;
     for( C='a';C<='z';C++)
     {
    	 System.out.println(C+ "");
     }
  
	}

}
