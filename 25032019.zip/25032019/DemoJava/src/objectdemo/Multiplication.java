package objectdemo;

public class Multiplication {

	public static void main(String[] args)
	 {
            int num = 8;
	        for(int i = 1; i <= 10; ++i)                              
	        {
	            System.out.printf("%d * %d = %d \n", num, i, num * i);
	        }
	    }
	
		

	}
                                            //int num = 0;
                                          //String str = "foo";
 
                                         //System.out.println(num + " " + str);		// without using %d and %s
                                        //System.out.printf("%d %s\n", num, str);		// using %d and %s

